%write a function hyperbolic to calculate the hyperbolic 
%sine, consine, and
%tangent functions as defined in Exercise 6.20.
%argument sinh, cosh, or tanh.

clear;
clc;

x = input('Enter x value: ');

hyperbolic(x);

fprintf('hyperbolic', ans);
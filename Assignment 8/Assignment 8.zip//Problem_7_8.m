%create an array of 1000,000 samples from function randn,
%plot a histogram of these samples over 21 bins.

y= randn(1000000,1);

hist(y,21);
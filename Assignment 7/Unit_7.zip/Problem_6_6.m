clear;
clc;

x = input('Enter temperature in F: ');

f_to_c(x);
fprintf('Temperature in C is %g \n', ans);
clear;
clc;

x1 = input('Enter x1: ');
y1 = input('Enter y1: ');
x2 = input('Enter x2: ');
y2 = input('Enter y2: ');
x3 = input('Enter x3: ');
y3 = input('Enter y3: ');

area_triangle(x1,y1,x2,y2,x3,y3);

fprintf('Area of the triangle: %g \n', ans);
function ouput= f_to_c(T);

ouput = (5/9) * (T-32);